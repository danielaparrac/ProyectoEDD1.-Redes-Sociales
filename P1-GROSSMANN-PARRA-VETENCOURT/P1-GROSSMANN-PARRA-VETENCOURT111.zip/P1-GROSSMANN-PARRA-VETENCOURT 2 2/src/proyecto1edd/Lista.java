/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1edd;

/**
 *
 * @author daniela
 * @param <T>
 */
public class Lista<T> {

    private Nodo<T> pFirst;
    private int size;
    private Nodo<T> pLast;

    public Lista() {
        this.pFirst = null;
        this.size = 0;
        this.pLast = null;
    }

    public boolean esVacio() {
        return pFirst == null;
    }

    public void InsertarFinal(T dato) {
        Nodo newnodo = new Nodo(dato);
        Nodo aux = pFirst;
        if (esVacio()) {
            pFirst = newnodo;
        } else {
            while (aux.getpNext() != null) {
                aux = aux.getpNext();
            }
            aux.setpNext(newnodo);
        }
        size++;
    }

    public void Imprimir() {
        Nodo aux = pFirst;
        if (esVacio()) {
            System.out.println("La lista es vacía");
        } else {
            while (aux != null) {
                System.out.println(aux.getDato());
                aux = aux.getpNext();
            }
        }
    }

    public void EliminarFinal() {
        Nodo aux = pFirst;
        if (!esVacio()) {
            while (aux.getpNext().getpNext() != null) {
                aux = aux.getpNext();
            }
            aux.setpNext(null);
            size--;
        }
    }

    public void eliminarElemento(T dato) {
        while (pFirst != null && pFirst.getDato() == dato) {
            pFirst = pFirst.getpNext();
        }

        if (esVacio()) {

            return;
        }

        Nodo actual = pFirst;
        Nodo anterior = null;

        while (actual != null) {
            if (actual.getDato() == dato) {
                anterior.setpNext(actual.getpNext());
            } else {
                anterior = actual;
            }
            actual = actual.getpNext();
        }
    }

//    public boolean buscar(T dato) {
//        Nodo aux = pFirst;
//        while (aux != null) {
//            if (aux.getDato() == dato) {
//                System.out.println("elemento encontrado");
//                return true;
//            }
//            aux = aux.getpNext();
//        }
//        System.out.println("elemento no encontrado");
//        return false; // Elemento no encontrado
//    }

    public Nodo<T> getpFirst() {
        return pFirst;
    }

    public void setpFirst(Nodo<T> pFirst) {
        this.pFirst = pFirst;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Nodo<T> getpLast() {
        return pLast;
    }

    public void setpLast(Nodo<T> pLast) {
        this.pLast = pLast;
    }

}
