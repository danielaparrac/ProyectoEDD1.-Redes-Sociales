/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1edd;

import java.awt.Color;


/**
 *
 * @author gabriellavetencourt
 */
public class Kosaraju {

    private Grafo grafo;
    private Lista<Lista> sccList;
    private Pila stack;
    private Mapa m;


    public Kosaraju(Grafo grafo, Mapa m) {
        this.grafo = grafo;
        this.sccList = new Lista();
        this.stack = new Pila();
        this.m = m;
    }
     private void DFS(int v, boolean[] visited, Pila stack) {
        visited[v] = true;
        for (int i = 0; i < v; i++) {
            if (grafo.getMatrizA()[v][i] == 1 && !visited[i]) {
                DFS(i, visited, stack);
            }
        }
        stack.push(v);
    }

    private void DFS2(int v, boolean[] visited, Lista component) {
        visited[v] = true;
        component.InsertarFinal(grafo.getUsuarios()[v].getNombre());

        for (int i = 0; i < grafo.getusuarioSize(); i++) {
            if (grafo.getMatrizA()[v][i] == 1 && !visited[i]) {
                DFS2(i, visited, component);
            }
        }
    }

    public Lista<Lista> getScc() {
 
        boolean[] visited = new boolean[grafo.getusuarioSize()];
        
        for (int i = 0; i < grafo.getusuarioSize(); i++) {
            if (!visited[i]) {
                DFS(i, visited, stack);
            }
        }

        visited = new boolean[grafo.getusuarioSize()];

        while (!stack.isEmpty()) {
            int v = (int) stack.pop();
            if (!visited[v]) {
                Lista<Integer> component = new Lista<>();
                DFS2(v, visited, component);
                sccList.InsertarFinal(component);
            }
        }
        return sccList;
    }
    
    public void CambiarColor() {
    Color[] colores = {Color.red, Color.green, Color.blue, Color.cyan, Color.pink,Color.orange, Color.magenta }; // Puedes agregar más colores si es necesario
    Nodo aux = sccList.getpFirst();
    int colorIndex = 0; // Índice para obtener el color de la lista actual
    while (aux != null) {
        Lista lista = (Lista) aux.getDato();
        Nodo aux2 = lista.getpFirst();
        Color color = colores[colorIndex]; // Obtiene el color actual
        while (aux2 != null) {
            for (int i = 0; i < grafo.getusuarioSize(); i++) {
                if (aux2.getDato().toString().equals(grafo.getUsuarios()[i].getNombre().trim())) {
                    m.getCirculo().get(i).setColor(color); // Asigna el color al nodo en el mapa (m)
                }
            }
            aux2 = aux2.getpNext();
        }
        aux = aux.getpNext();
        colorIndex = (colorIndex + 1) % colores.length; // Avanza al siguiente color en el array de colores
    }
    m.repaint();
}

}


