/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1edd;

/**
 *
 * @author federicagrossmann
 */
public class Pila<T> {
    //LIFO

    private Nodop<T> pCima;
    private Nodop<T> pBase;
    private int size;

    public Pila() {
        this.pCima = null;
        this.pBase = null;
        this.size = 0;

    }

    //agg elemento
    public void push(T data) {
        Nodop<T> nuevoNodo = new Nodop<>(data);
        if (isEmpty()) {
            pCima = nuevoNodo;
            pBase = nuevoNodo;
        } else {
            nuevoNodo.setpNext(pCima);
            pCima = nuevoNodo;
        }
        size++;
    }

    //elimina elemento
    public T pop() {
        if (isEmpty()) {
            System.out.println("Pila vacía"); //NO SIRVE SI ESTA VACIA
        }
        T datoEliminado = pCima.getData();
        if (pCima == pBase) {
            pCima = null;
            pBase = null;
        } else {
            pCima = pCima.getpNext();
        }
        size--;
        return datoEliminado;
    }

    //retorna cima
    public T top() {
        if (isEmpty()) {
            System.out.println("Pila vacía"); //NO SIRVE SI ESTA VACIA
        }
        return pCima.getData();
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void imprimir() {
        if (isEmpty()) {
            System.out.println("La pila está vacía.");
        } else {
            Nodop<T> actual = pCima;
            while (actual != null) {
                System.out.print(actual.getData() + " ");
                actual = actual.getpNext();
            }
            System.out.println();
        }
    }

    /**
     * @return the pCima
     */
    public Nodop<T> getpCima() {
        return pCima;
    }

    /**
     * @param pCima the pCima to set
     */
    public void setpCima(Nodop<T> pCima) {
        this.pCima = pCima;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }

    /**
     * @return the pBase
     */
    public Nodop<T> getpBase() {
        return pBase;
    }

    /**
     * @param pBase the pBase to set
     */
    public void setpBase(Nodop<T> pBase) {
        this.pBase = pBase;
    }

}
